import { useState } from "react";
import "./App.css";
import Nav from "./components/Nav";
import Sagar from "./components/Sagar";
import Sidebar from "./components/Sidebaar";
import Alertmode from "./components/Alertmode";
// import { BrowserRouter as Router, Switch, Route } from "react-router-dom";


import {
  BrowserRouter as Router,
  Switch,
  Route,
} from "react-router-dom";


function App() {
  const [mode, setMode] = useState("light"); //Whether dark mode is enable or not.
  const [alert, setAlert] = useState(null);

  const showAlert = (message, type) => {
    setAlert({
      msg: message,
      type: type,
    });
    setTimeout(() => {
      setAlert(null);
    }, 1500);
  };

  const toggleMode = () => {
    if (mode === "light") {
      setMode("dark");
      document.body.style.backgroundColor = "gray";
      showAlert("Mode change into dark", "success");
      // document.title = "Text-Utils Dark Mode"
      //  setInterval(() => {
      //    document.title = "Text_utils is amazing"
      //  }, 2000);
      //  setInterval(() => {
      //    document.title = "Install Text-utils"
      // }, 1500);
    } else {
      setMode("light");
      document.body.style.backgroundColor = "white";
      // document.title = "Text-Utils Light Mode"
      showAlert("Mode change into light", "success");
    }
  };

  return (
    <>
{/* <Router>
      <Nav title="Text-utils" about="About Us" mode={mode} toggleMode={toggleMode}/>
      <Alertmode alert={alert}/>
      <div className="container mx-3 "/>
      <Switch>
          <Route path="/Sidebar">
            <Sidebar />
          </Route>
          <Route path="/">
          <Sagar showAlert={showAlert} heading="Enter the text to analyze" mode={mode}/>
          </Route>
      </Switch>
       
      <div/> 
      <Sidebar/> */}
     
      {/* </Router> */}
      <Nav title="Text-utils" about="About Us" mode={mode} toggleMode={toggleMode}/>
      <Alertmode alert={alert}/>
      <div className="container" my-3>
      <Sagar showAlert={showAlert} heading="Enter the text to analyze" mode={mode}/>
      </div>
      </>
  );
}

export default App;
